<section id="searchform">
	<form action="" method="get">
		<fieldset>
			<p>
				<input type="text" value="" name="m_recherche" id="m_recherche" />
                <input type="submit" name="m_sub" value="Rechercher" />
            </p>
        </fieldset>   
    </form>
</section>