			<footer>
				<?php bloginfo('name'); ?> est propulsé par <a href="http://wordpress.org">WordPress</a>.
			</footer>
		</div>
		<?php wp_footer(); ?>
	</body>
</html>
