<?php get_header(); ?>
<div class="main archive">
	<?php query_posts('posts_per_page=20'); ?>
	<?php get_template_part('loop'); ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
