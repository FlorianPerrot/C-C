﻿<div id="sous_page">
	<nav class="menu_secondaire">
         <h2>Présentation</h2>
            <p><img />Objectif</p>
            <p><img />Tourisme adapté</p>
            <p><img />Pôle intégration</p>
         
    </nav>
</div>