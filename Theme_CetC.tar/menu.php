<nav id="menu">
        <h2>Menu</h2>
            <p><a href="#"><object type="image/svg+xml" data="wp-content/themes/CetC_theme/img/house.svg" width="25px" height="25px"></object>Accueil</a></p>
            <p><a href="#"><object type="image/svg+xml" data="wp-content/themes/CetC_theme/img/house.svg" width="25px" height="25px"></object>Présentation</a></p>
                        <!-- MENU SECONDAIRE dans sous_page
                        
                            <p>Objectif</p>
                            <p>Tourisme adapté</p>
                            <p>Pôle intégration</p>
                        
                        -->
            <p><a href="#"><object type="image/svg+xml" data="wp-content/themes/CetC_theme/img/house.svg" width="25px" height="25px"></object>Articles</a></p>
            <p><a href="#"><object type="image/svg+xml" data="wp-content/themes/CetC_theme/img/house.svg" width="25px" height="25px"></object>Forum</a></p>
            <p><a href="#"><object type="image/svg+xml" data="wp-content/themes/CetC_theme/img/house.svg" width="25px" height="25px"></object>Documents</a></p>
        

        <h2>Partenaires</h2>
            <p><a href="#">part1</a></p>
            <p><a href="#">part2</a></p>
            <p><a href="#">part3</a></p>
</nav>
